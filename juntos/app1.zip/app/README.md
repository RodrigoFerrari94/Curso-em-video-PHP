# calculo-de-forca
 app para calcular 1RM
